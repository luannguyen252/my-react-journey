module.exports = {
  images: {
    domains: ["avatars.githubusercontent.com"],
  },
};
