import React from "react";

const Home = () => {
  return (
    <>
      <section></section>
    </>
  );
};

export default Home;
