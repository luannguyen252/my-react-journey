export const main = {
  /* main styles */  
};