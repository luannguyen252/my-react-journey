# Change Log

## V0.1.0

**04/25/2020**
### Initial Development Release

- Added Material-UI as base framework
- Created basic admin dashboard