export default interface iToken {
  jwt: string;
  id: number;
  email: string;
  name: string;
  picture: string;
}
