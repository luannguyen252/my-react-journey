export default interface IUser {
  jwt: string;
  id: number;
  username: string;
}
