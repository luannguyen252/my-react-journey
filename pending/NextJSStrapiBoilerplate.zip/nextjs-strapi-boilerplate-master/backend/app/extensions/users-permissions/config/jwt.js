module.exports = {
  jwtSecret: process.env.JWT_SECRET || "aa784526-bc31-4de1-8793-d334f862d2f4",
};
