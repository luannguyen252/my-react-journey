export { default as Home } from "./Home";
export { default as Movies } from "./Movies";
export { default as NotFound } from "./404";
