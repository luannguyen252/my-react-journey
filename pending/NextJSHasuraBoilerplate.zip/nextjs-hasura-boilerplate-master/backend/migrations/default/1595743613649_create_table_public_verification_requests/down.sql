DROP TABLE "public"."verification_requests";
