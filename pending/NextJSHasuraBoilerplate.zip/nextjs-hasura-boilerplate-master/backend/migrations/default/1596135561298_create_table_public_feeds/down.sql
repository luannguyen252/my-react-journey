DROP TABLE "public"."feeds";
