DROP TABLE "public"."sessions";
