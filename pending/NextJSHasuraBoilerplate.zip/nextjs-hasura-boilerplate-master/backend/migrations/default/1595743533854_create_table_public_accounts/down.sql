DROP TABLE "public"."accounts";
