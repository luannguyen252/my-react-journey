declare module "next-auth/client";
declare module "next-auth";
declare module "next-auth/providers";
