export default interface iToken {
  id: number;
  email: string;
  name: string;
  picture: string;
}
