# Brian Lovin Next
The code that powers [brianlovin.com](https://brianlovin.com).

## Development
Clone the repository:
`git clone git@github.com:brianlovin/brian-lovin-next.git`

`cd` into the directory:
`cd brian-lovin-next`

Install dependencies:
`yarn`

Start the client:
`yarn dev`

Open the site:
`localhost:3000`
