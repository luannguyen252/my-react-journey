import { Toaster } from 'react-hot-toast'

export default function Toast() {
  return (
    <Toaster
      position="bottom-center"
      reverseOrder={false}
      gutter={8}
      containerClassName=""
      containerStyle={{}}
      toastOptions={{
        // Define default options
        className: 'bg-white dark:bg-gray-700 text-primary',
        duration: 2000,
        success: {
          duration: 2000,
          theme: {
            primary: 'green',
            secondary: 'black',
          },
        },
        error: {
          duration: 2000,
          theme: {
            primary: 'red',
            secondary: 'white',
          },
        },
      }}
    />
  )
}
