import * as React from 'react'
import { December } from './December'
import { November } from './November'
import { October } from './October'

export function Year2020() {
  return (
    <>
      <December />
      <November />
      <October />
    </>
  )
}
