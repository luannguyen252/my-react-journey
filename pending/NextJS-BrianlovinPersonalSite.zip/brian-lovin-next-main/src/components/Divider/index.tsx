export default function Divider() {
  return (
    <div className="w-full border-t border-gray-200 dark:border-gray-800" />
  )
}
