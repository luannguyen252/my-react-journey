export function isMe(_, __, { isMe }) {
  return isMe
}
