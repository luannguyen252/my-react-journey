import Query from '~/graphql/resolvers/queries'
import Mutation from '~/graphql/resolvers/mutations'

export default {
  Query,
  Mutation,
}
