export default {
  title: "Next.js Chakra UI Template",
  description: "A starter Template for Next.js with Chakra UI.",
};

export const links = [
  { title: "Home", path: "/" },
  { title: "About", path: "/About" },
  { title: "Contact", path: "/contact" },
];
