const NextSeo = {
  openGraph: {
    type: "website",
    url: "https://next-js-tailwindcss-template.vercel.app/",
    site_name: "next-js-tailwindcss-template",
  },
};

export default NextSeo;
