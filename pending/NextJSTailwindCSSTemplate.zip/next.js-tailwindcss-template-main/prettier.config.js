module.exports = {
  // default prettier config is actually good
};
