export { default as Modal } from "./Modal/Modal";
export { default as Search } from "./Search/Search";
export { default as SinglePokemon } from "./SinglePokemon/SinglePokemon";
export { default as Pokemons } from "./Pokemons/Pokemons";
