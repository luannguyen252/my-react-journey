# react-context-example
A complete example of how to architect a React app using the Context API
