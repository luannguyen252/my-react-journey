# Password Strength Meter for React
A user-friendly password strength meter, written in React.

View the [live demo](https://warm-garden-25373.herokuapp.com/).

Find the full tutorial on how to create this from scratch over at [https://upmostly.com/tutorials/build-a-password-strength-meter-react/](https://upmostly.com/tutorials/build-a-password-strength-meter-react)

![blh](https://upmostly.com/wp-content/uploads/password-strength-meter-1.gif)
