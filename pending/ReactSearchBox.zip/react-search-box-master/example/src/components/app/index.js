import React, { Component } from 'react'

import IndexPage from '../../pages'

export default class App extends Component {
  render() {
    return (
      <div className="layout-container">
        <IndexPage />
      </div>
    )
  }
}
