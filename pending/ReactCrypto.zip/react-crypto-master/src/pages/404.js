import { Layout } from 'partials';
// TODO: Import the react-router-dom dependencies here

/* TODO: Implement the UI for the 404 page
 *  - It must at least include a link to go back to the homepage
 */
const NotFound = () => <Layout>{/* TODO: Add your code here */}</Layout>;

export default NotFound;
