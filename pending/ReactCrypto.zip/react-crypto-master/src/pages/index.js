export { default as Home } from './Home';
export { default as Coins } from './Coins';
export { default as NotFound } from './404';
export { default as Watchlist } from './Watchlist';
export { default as About } from './About';
export { default as Terms } from './Terms';
export { default as PrivacyPolicy } from './PrivacyPolicy';
